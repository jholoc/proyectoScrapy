# -*- coding: utf-8 -*-
#Datos para la base de datos
HOST = "localhost"
USER = "root"
PASS = "root"
BD = "ScrapyMenu"
